export default function CrearProyecto(){
    return (
        <h1>Creando proyecto</h1>
    );
}